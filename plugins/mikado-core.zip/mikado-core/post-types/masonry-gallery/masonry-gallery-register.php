<?php
/**
 * Created by PhpStorm.
 * User: korisnik
 * Date: 30/3/2015
 * Time: 11:25 AM
 */

namespace MikadoCore\CPT\MasonryGallery;

use MikadoCore\Lib;

/**
 * Class MasonryGalleryRegister
 * @package MikadoCore\CPT\MasonryGallery
 */
class MasonryGalleryRegister implements Lib\PostTypeInterface  {
    /**
     * @var string
     */
    private $base;

    public function __construct() {
        $this->base = 'masonry_gallery';
        $this->taxBase = 'masonry_gallery_category';
    }

    /**
     * @return string
     */
    public function getBase() {
        return $this->base;
    }

    /**
     * Registers custom post type with WordPress
     */
    public function register() {
        $this->registerPostType();
        $this->registerTax();
    }

    /**
     * Registers custom post type with WordPress
     */
    private function registerPostType() {
        register_post_type($this->base,
            array(
                'labels' 		=> array(
                    'name' 				=> __('Masonry Gallery','mkd_core' ),
                    'all_items'			=> __('Masonry Gallery Items','mkd_core'),
                    'singular_name' 	=> __('Masonry Gallery Item','mkd_core' ),
                    'add_item'			=> __('New Masonry Gallery Item','mkd_core'),
                    'add_new_item' 		=> __('Add New Masonry Gallery Item','mkd_core'),
                    'edit_item' 		=> __('Edit Masonry Gallery Item','mkd_core')
                ),
                'public'		=>	false,
                'show_in_menu'	=>	true,
                'rewrite' 		=> 	array('slug' => 'masonry_gallery'),
                'menu_position' => 	4,
                'show_ui'		=>	true,
                'has_archive'	=>	false,
                'hierarchical'	=>	false,
                'supports'		=>	array('title', 'thumbnail')
            )
        );
    }

    /**
     * Registers custom taxonomy with WordPress
     */
    private function registerTax() {
        $labels = array(
            'name' => __( 'Masonry Gallery Categories', 'taxonomy general name' ),
            'singular_name' => __( 'Masonry Gallery Category', 'taxonomy singular name' ),
            'search_items' =>  __( 'Search Masonry Gallery Categories','mkd_core' ),
            'all_items' => __( 'All Masonry Gallery Categories','mkd_core' ),
            'parent_item' => __( 'Parent Masonry Gallery Category','mkd_core' ),
            'parent_item_colon' => __( 'Parent Masonry Gallery Category:','mkd_core' ),
            'edit_item' => __( 'Edit Masonry Gallery Category','mkd_core' ),
            'update_item' => __( 'Update Masonry Gallery Category','mkd_core' ),
            'add_new_item' => __( 'Add New Masonry Gallery Category','mkd_core' ),
            'new_item_name' => __( 'New Masonry Gallery Category Name','mkd_core' ),
            'menu_name' => __( 'Masonry Gallery Categories','mkd_core' ),
        );

        register_taxonomy($this->taxBase, array($this->base), array(
            'hierarchical' => true,
            'labels' => $labels,
            'show_ui' => true,
            'query_var' => true,
            'show_admin_column' => true,
            'rewrite' => array( 'slug' => 'masonry-gallery-category' ),
        ));
    }
}